//
//  EditViewController.swift
//  ReminderOnNotes
//
//  Created by MacBook Pro on 03/01/2024.
//

import UIKit

class EditViewController: UIViewController {
    @IBOutlet weak var titleTextField: UITextField!
    @IBOutlet weak var dateTimePicker: UIDatePicker!
    @IBOutlet weak var textView: UITextView!
    
    var editableReminder: MyReminder?
    public var completion: ((MyReminder) -> Void)?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        if let reminder = editableReminder {
            titleTextField.text = reminder.title
            dateTimePicker.date = reminder.date
            textView.text = reminder.body
        }
        
        navigationItem.rightBarButtonItem = UIBarButtonItem(title: "Save", style: .done, target: self, action: #selector(didTapSaveButton))
    }
    
    @objc func didTapSaveButton() {
        print("Save button tapped")
        
        guard let titleText = titleTextField.text, !titleText.isEmpty else {
            print("Title is empty")
            return
        }
        
        let targetDate = dateTimePicker.date
        let editedReminder = MyReminder(title: titleText, date: targetDate, body: textView.text, identifier: "id_\(titleText)")
        
        completion?(editedReminder)
        
        navigationController?.popViewController(animated: true)
    }
}
