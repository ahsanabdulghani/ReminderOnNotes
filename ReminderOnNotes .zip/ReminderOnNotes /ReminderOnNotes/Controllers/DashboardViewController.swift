//
//  DashboardViewController.swift
//  ReminderOnNotes
//
//  Created by 4STAR on 31/12/2023.
//

import UIKit

class DashboardViewController: UIViewController {
    
    override func viewDidLoad() {
        super.viewDidLoad()
    }
    
    @IBAction func setReminderClickBtn(_ sender: Any) {
    }
    @IBAction func moreOptionPressed(_ sender: Any) {
        let vc = storyboard?.instantiateViewController(withIdentifier: "MoreOptionVC") as! MoreOptionVC
        navigationController?.pushViewController(vc, animated: true)
        
    }
    
}
