//
//  MoreOptionVC.swift
//  ConvertIt Pro
//
//  Created by Shahzad Hussain on 06/11/2023.
//

import UIKit
import StoreKit


class MoreOptionVC: UIViewController {
    @IBOutlet var btns: [UIButton]!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        
    }
    @IBAction func feedBackPressed(_ sender: Any) {
        let vc = storyboard?.instantiateViewController(withIdentifier: "FeedbackPopUpVC") as! FeedbackPopUpVC
        vc.modalTransitionStyle = .crossDissolve
        vc.modalPresentationStyle = .overFullScreen
        present(vc, animated: true)
    }
    @IBAction func privacyPolicyPressed(_ sender: Any) {
        let vc = storyboard?.instantiateViewController(withIdentifier: "DescriptionVC") as! DescriptionVC
        vc.newTitle = "Privacy Policy"
        vc.newDescription = """
         Personal Information: We do not collect any personally identifiable information (PII) that can directly identify you, such as your name, address, or contact details.

         Non-Personal Information: We may collect non-personal information that does not directly identify you. This may include information such as device information, operating system, and anonymous usage data.

          How We Use Your Information

         We may use the collected information for the following purposes:

         App Improvement: To improve and enhance the functionality and features of the App.

         Usage Analytics: To analyze how the App is used, troubleshoot issues, and provide user support.

          Third-Party Services

         The App may include links to third-party websites or services. We are not responsible for the privacy practices of these third-party services. Please review their privacy policies when using their services.
"""
        navigationController?.pushViewController(vc, animated: true)
    }
    @IBAction func termsPressed(_ sender: Any) {
        let vc = storyboard?.instantiateViewController(withIdentifier: "DescriptionVC") as! DescriptionVC
        vc.newTitle = "Terms & Conditions"
        vc.newDescription = """
         ReminderOnNotes" is provided for personal use and reference purposes only.
         While we strive for accuracy, we cannot guarantee the precision of the conversions in all cases. Users are encouraged to double-check results for critical applications.
         The app is not intended as a replacement for professional advice or critical calculations.
Users must not engage in any activity that may damage, disrupt, or compromise the app's functionality.
This includes attempts to hack, reverse engineer, or distribute harmful code.
Users should respect the rights and privacy of others when using the app
We welcome user feedback to improve our app. If you encounter issues or have suggestions for enhancements, please contact us through the provided support channels.
We will make reasonable efforts to address user concerns and provide support
"""
        navigationController?.pushViewController(vc, animated: true)
    }
    @IBAction func sharePressed(_ sender: Any) {
        if let link = NSURL(string: "https://www.apple.com") {
            let objectsToShare = [link] as [Any]
            let activityVC = UIActivityViewController(activityItems: objectsToShare, applicationActivities: nil)
            self.present(activityVC, animated: true, completion: nil)
        }
    }
    @IBAction func giveRatingPressed(_ sender: Any) {
        if #available(iOS 10.3, *) {
            SKStoreReviewController.requestReview()
        } else {
            
        }
    }
    
}
