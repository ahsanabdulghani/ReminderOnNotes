//
//  SplashViewController.swift
//  ReminderOnNotes
//
//  Created by MacBook Pro on 03/01/2024.
//

import UIKit

class SplashViewController: UIViewController {
    
    @IBOutlet weak var activityIndicator: UIActivityIndicatorView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        activityIndicator.startAnimating()
        
        DispatchQueue.global().async {
            sleep(3)
            
            DispatchQueue.main.async {
                self.activityIndicator.stopAnimating()
                
                let mainViewController = UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "home")
                
                UIApplication.shared.windows.first?.rootViewController = mainViewController
            }
        }
    }
    
    
    
}
