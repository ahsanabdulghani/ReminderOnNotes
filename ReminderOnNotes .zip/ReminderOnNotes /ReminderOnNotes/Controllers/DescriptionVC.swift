//
//  DescriptionVC.swift
//  ConvertIt Pro
//
//  Created by Shahzad Hussain on 06/11/2023.
//

import UIKit

class DescriptionVC: UIViewController {
    @IBOutlet weak var backView: UIView!
    @IBOutlet weak var descriptionTV: UITextView!
    var newTitle = ""
    var newDescription = ""
    override func viewDidLoad() {
        super.viewDidLoad()
        self.title = newTitle
        self.descriptionTV.text = newDescription
    }
    
}
