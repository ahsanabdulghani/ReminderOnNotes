//
//  ViewController.swift
//  ReminderOnNotes
//
//  Created by MacBook Pro on 03/01/2024.
//

import UIKit

struct MyReminder: Codable {
    let title: String
    let date: Date
    let body: String
    let identifier: String
}

class ViewController: UIViewController {
    
    @IBOutlet weak var tbView: UITableView!
    var models = [MyReminder]()
    override func viewDidLoad() {
        super.viewDidLoad()
        loadReminders()
        tbView.isEditing = true
        
    }
    @IBAction func didTapAdd() {
        let storyboard = UIStoryboard(name: "Main", bundle: nil)
        if let addViewController = storyboard.instantiateViewController(withIdentifier: "AddViewController") as? AddViewController {
            addViewController.title = "Add New Reminder"
            addViewController.completion = { [weak self] title, body, date in
                guard let self = self else { return }
                
                let newReminder = MyReminder(title: title, date: date, body: body, identifier: "id_\(title)")
                
                self.models.append(newReminder)
                
                self.tbView.reloadData()
                
                self.saveReminders()
                
                print("Reminder added successfully")
            }
            self.navigationController?.pushViewController(addViewController, animated: true)
        }
    }
    
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        print("ViewWillAppear - Number of reminders: \(models.count)")
    }
    
    private func saveReminders() {
        let encoder = JSONEncoder()
        if let encoded = try? encoder.encode(models) {
            UserDefaults.standard.set(encoded, forKey: "reminders")
        }
    }
    private func loadReminders() {
        if let remindersData = UserDefaults.standard.data(forKey: "reminders"),
           let decodedReminders = try? JSONDecoder().decode([MyReminder].self, from: remindersData) {
            models = decodedReminders
            tbView.reloadData()
        }
    }
}

extension ViewController: UITableViewDataSource, UITableViewDelegate {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return models.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "cell", for: indexPath) as! ReminderTbViewCell
        cell.title.text = models[indexPath.row].title
        
        let date = models[indexPath.row].date
        let formatter = DateFormatter()
        formatter.dateFormat = "MMM dd, yyyy HH:mm"
        cell.dateLbl.text = formatter.string(from: date)
        
        return cell
    }
    func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCell.EditingStyle, forRowAt indexPath: IndexPath) {
        if editingStyle == .delete {
            models.remove(at: indexPath.row)
            
            tableView.deleteRows(at: [indexPath], with: .fade)
            
            saveReminders()
        }
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 200
    }
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let storyboard = UIStoryboard(name: "Main", bundle: nil)
        if let editViewController = storyboard.instantiateViewController(withIdentifier: "EditViewController") as? EditViewController {
            editViewController.title = "Edit Reminder"
            editViewController.editableReminder = models[indexPath.row]
            editViewController.completion = { [weak self] editedReminder in
                guard let self = self else { return }
                
                self.models[indexPath.row] = editedReminder
                
                tableView.reloadRows(at: [indexPath], with: .automatic)
                
                self.saveReminders()
            }
            
            self.navigationController?.pushViewController(editViewController, animated: true)
        }
    }
}
