//
//  AddViewController.swift
//  ReminderOnNotes
//
//  Created by Pawan iOS on 22/11/2022.
//

// AddViewController.swift

import UIKit
import UserNotifications

class AddViewController: UIViewController {
    
    @IBOutlet weak var titleTextField: UITextField!
    @IBOutlet weak var dateTimePicker: UIDatePicker!
    @IBOutlet weak var textView: UITextView!
    
    public var completion: ((String, String, Date) -> Void)?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        navigationItem.rightBarButtonItem = UIBarButtonItem(title: "Save", style: .done, target: self, action: #selector(didTapSaveButton))
    }
    
    @objc func didTapSaveButton() {
        print("Save button tapped")
        
        guard let titleText = titleTextField.text, !titleText.isEmpty,
              let bodyText = textView.text, !bodyText.isEmpty else {
            
            print("Title is empty")
            return
        }
        
        let targetDate = dateTimePicker.date
        completion?(titleText, bodyText, targetDate)
        
        
        scheduleNotification(title: titleText, body: bodyText, date: targetDate)
        
        
        navigationController?.popViewController(animated: true)
    }
    
    func scheduleNotification(title: String, body: String, date: Date) {
        let content = UNMutableNotificationContent()
        content.title = title
        content.body = body
        
        let dateComponents = Calendar.current.dateComponents([.year, .month, .day, .hour, .minute], from: date)
        
        let trigger = UNCalendarNotificationTrigger(dateMatching: dateComponents, repeats: false)
        
        let request = UNNotificationRequest(identifier: "reminderNotification_\(title)", content: content, trigger: trigger)
        
        UNUserNotificationCenter.current().add(request) { (error) in
            if let error = error {
                print("Error scheduling notification: \(error)")
            } else {
                print("Notification scheduled successfully for \(date)")
            }
        }
    }
}
