//
//  ReminderTbViewCell.swift
//  ReminderOnNotes
//
//  Created by 4STAR on 31/12/2023.
//

// ReminderTbViewCell.swift

import UIKit

class ReminderTbViewCell: UITableViewCell {
    @IBOutlet weak var dateLbl: UILabel!
    @IBOutlet weak var title: UILabel!

    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)
        // Configure the view for the selected state
    }
}
